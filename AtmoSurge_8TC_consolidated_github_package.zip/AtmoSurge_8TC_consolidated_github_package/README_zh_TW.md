# AtmoSurge 8TC Consolidated Package

## 目的

本套件只保留最终评估需要的合并 CSV、SLOSH 记录和诊断说明；早期/错误的 Holland working-period 中间 CSV 不纳入 GitHub 包。

## 正確物理理解

Holland 公式中 `Pc` 是颱風中心氣壓，`Penv/Pn` 是環境氣壓，`P(r)` 是根据測站到颱風中心距离 `r` 算出的測站局地氣壓。AtmoSurge 的 pressure 输入应使用測站局地氣壓或實測測站氣壓，不应直接使用中心氣壓。

## 主要结论

Mangkhut2018/PLC 的低估不是因为把中心氣壓误送入 AtmoSurge，而是 raw Holland forcing 在觀測峰值時段明顯偏弱、错时。觀測峰值窗口 TC_Group 显示 PLC 風速 41.64 m/s、最低氣壓 978.7 hPa、風向 71.3 度；但 Holland 在最接近觀測峰值时只给出 20.66 m/s、1005.21 hPa、156.15 度。

用 TC_Group 實測測站气象作为输入时，AtmoSurge 对 Mangkhut2018/PLC 预测可升至约 2.59 m，说明模型本体有响应能力；raw Holland 端到端低估主要是气象 forcing 问题。

## README 閾值口径

按 AtmoSurge README：`storm surge > 0.8 m` 时容許誤差为 `0.4 m`。因此本包使用：

```text
warning threshold = observed surge > 0.8 m
tolerance hit = abs(predicted - observed) <= 0.4 m, evaluated for observed > 0.8 m
```

## CSV 檔案

```text
data/consolidated_atmosurge_slosh_8tc_event_peak.csv
data/consolidated_metrics_0p8m_tolerance.csv
data/slosh_errors_all.csv
data/slosh_errors_hindcast_8tc.csv
diagnostics/mangkhut2018_plc_root_cause_summary.csv
diagnostics/mangkhut2018_plc_manual_api_sensitivity.csv
```

## 建議報告写法

请分开報告三条线：

1. AtmoSurge skill test：使用 TC_Group/Timeseries 的測站實測气象输入，展示 DL storm-surge response 能力。
2. Raw Holland end-to-end test：使用 Holland `P(r)` 和測站风，评估真实業務链条，但结果包含气象 forcing 誤差。
3. Calibrated/blended forcing test：用 ERA5/HKO station/NWP 与 Holland 融合或 leave-one-TC-out bias correction，展示可改进的生产方案。

## 如何改善 wind forecast 太低的问题

建议不要只依赖 raw Holland 参数场：

- 使用 10 分钟到 1 小时级别的時序 forcing adapter，而不是单时刻 manual endpoint。
- 用 HKO station / ERA5 / NWP 对 Holland 風速、氣壓和風向做 station-wise bias correction。
- 对 RMW、B、translation flow 做 leave-one-TC-out 校準，避免用目標事件本身作弊。
- 对 PLC 这类地形/海湾敏感測站加入風向扇区校正和局地放大系数。
- 報告时把 raw Holland forcing error 与 AtmoSurge model error 拆开，不要把二者混成一个模型失败。
