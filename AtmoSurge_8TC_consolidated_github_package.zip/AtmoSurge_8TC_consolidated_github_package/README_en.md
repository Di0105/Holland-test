# AtmoSurge 8TC Consolidated Package

## Purpose

This package keeps only the final consolidated CSV files, SLOSH records, and diagnostic notes needed for GitHub. Earlier or incorrect Holland working-period intermediate CSV files are intentionally excluded.

## Correct Physical Interpretation

In the Holland pressure model, `Pc` is the tropical-cyclone central pressure, `Penv/Pn` is environmental pressure, and `P(r)` is the local station pressure at distance `r` from the cyclone centre. AtmoSurge pressure input should be station/local pressure, not central pressure.

## Main Finding

The Mangkhut2018/PLC underprediction is not caused by feeding central pressure into AtmoSurge. It is mainly caused by weak and mistimed raw Holland forcing near the observed surge peak. TC_Group at the PLC observed peak window gives wind 41.64 m/s, pressure 978.7 hPa, and wind direction 71.3 degrees; raw Holland near the same peak gives only 20.66 m/s, 1005.21 hPa, and 156.15 degrees.

When TC_Group observed station meteorology is used as input, AtmoSurge predicts about 2.59 m for Mangkhut2018/PLC. This shows the DL surge-response model is responsive; the raw Holland end-to-end underprediction is primarily a meteorological forcing issue.

## README Threshold Convention

Following the AtmoSurge README statement that storm surge above 0.8 m has a 0.4 m tolerance, this package uses:

```text
warning threshold = observed surge > 0.8 m
tolerance hit = abs(predicted - observed) <= 0.4 m, evaluated for observed > 0.8 m
```

## CSV Files

```text
data/consolidated_atmosurge_slosh_8tc_event_peak.csv
data/consolidated_metrics_0p8m_tolerance.csv
data/slosh_errors_all.csv
data/slosh_errors_hindcast_8tc.csv
diagnostics/mangkhut2018_plc_root_cause_summary.csv
diagnostics/mangkhut2018_plc_manual_api_sensitivity.csv
```

## Recommended Reporting Structure

Report three separate lines of evidence:

1. AtmoSurge skill test: use observed station meteorology from TC_Group/Timeseries to demonstrate the DL storm-surge response skill.
2. Raw Holland end-to-end test: use Holland `P(r)` and station wind to evaluate the operational chain; this includes meteorological forcing errors.
3. Calibrated/blended forcing test: blend or bias-correct Holland with ERA5/HKO station/NWP forcing using leave-one-TC-out validation.

## How To Improve The Low Wind Forecast Problem

Do not rely on raw Holland forcing alone:

- Use a 10-minute to 1-hour time-series forcing adapter instead of a single-time manual endpoint.
- Apply station-wise bias correction to Holland wind, pressure, and direction using HKO station / ERA5 / NWP data.
- Calibrate RMW, B, and translation-flow assumptions with leave-one-TC-out validation.
- Add wind-sector and local amplification correction for sensitive stations such as PLC.
- Keep raw Holland forcing error separate from AtmoSurge model error in the report.


## Additional Journal-Style Figures And Interpretation

The package now includes a `figures/` directory with both PNG and PDF outputs:

```text
fig1_predicted_vs_observed_scatter
fig2_abs_error_distribution
fig3_method_metrics_0p8m_tolerance
fig4_mangkhut_plc_diagnostic
```

### What does Holland-driven AtmoSurge represent?

The current Holland-driven AtmoSurge run is not a complete historical maximum-storm-surge hindcast. It is an event-peak hindcast for the selected 8 TCs and 6 Hong Kong station pairs, driven by best-track parametric Holland local wind/pressure fields. It evaluates the end-to-end chain `parametric TC meteorology + DL surge response`. Because the forcing is controlled by TC centre position, Pc, Rmax, B, and translation flow, the result is highly sensitive to TC centre proximity, track timing, Rmax/B errors, and local station exposure.

Therefore, raw Holland-driven results should be interpreted as the performance of the TC-centre/track-parametric operational chain, not as the sole measure of AtmoSurge DL model skill.

### Observed-meteorology driven DL hindcast

To test the AtmoSurge model skill itself, this package uses judy5/TC_Group event-peak-window observed meteorology as input: maximum wind, minimum pressure, and wind direction. This compares maximum observed storm surge against observed-meteorology-driven AtmoSurge hindcast and is closer to the model's training/production feature distribution.

### Why does raw Holland underpredict Mangkhut2018/PLC?

At the observed peak window, TC_Group gives wind 41.64 m/s, pressure 978.7 hPa, and direction 71.3 deg. Raw Holland near the same peak gives only wind 20.66 m/s, station pressure 1005.21 hPa, and direction 156.15 deg. The main bottleneck is weak and mistimed wind/pressure/direction forcing, not pressure-input semantics.

### How to improve the low wind forecast / forcing issue

- Apply station-wise bias correction using TC_Group/HKO station/ERA5/NWP data.
- Correct Holland wind, station P(r), and wind direction separately.
- Calibrate Rmax, B, and translation-flow alpha with leave-one-TC-out validation.
- Add wind-sector amplification correction for locally sensitive stations such as PLC.
- Develop a true time-series forcing adapter so AtmoSurge receives 10-minute or hourly sequences rather than a single-time manual forcing input.
